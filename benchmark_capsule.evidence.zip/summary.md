# DNA-Lang Evidence Capsule: EXP-OLMO3-BEIR-SCIFACT-001

> Simulated retrieval: no model or dataset is loaded. Document IDs come from a seeded RNG and a relevant document is planted at a random rank (or left out), so the metrics test the evidence pipeline, not a model.

- **Retrieval Backend:** simulated-seeded-rng
- **Model Label (not loaded):** allenai/Olmo-3-7B-Instruct
- **Dataset Label (placeholder queries):** SciFact (test)
- **Canonical Spec Digest:** `34b3b2ca9a72033ebbce4ee37001a50b5f5a8841f99fae539088781bcd51f891`
- **Ledger Chain Digest:** `24e7f2367a911ba5a168b9dcea6ff4bf89e2c2a24e00fb0f8ad7f6efeb577a16`
- **Queries Evaluated:** 10
- **NDCG@10:** 0.3332
- **MRR@10:** 0.2006
- **CTC (derived score):** 0.6933
- **Execution Time:** 0.0043s
